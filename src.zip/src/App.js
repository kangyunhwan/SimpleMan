import React from 'react'
import './App.css'
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import Root from './pages/Root'
import Home from './pages/Home'
import Trending from './pages/Trending'
import Products from './pages/Products'
import About from './pages/About'
import ProductsDetail from './pages/ProductsDetail';


export default function App() {

  

  const router = createBrowserRouter([
    {
      path:'/',
      element:<Root/>,
      children:[
        {index:true,element:<Home/>},
        {path:'/trending',element:<Trending/>},
        {path:'/products',element:<Products/>},
        {path:'/products/:productId',element:<ProductsDetail/>},
        {path:'/about',element:<About/>},
        

      ]
    }
  ])

  return (
    <RouterProvider router={router}/>
  );
}





