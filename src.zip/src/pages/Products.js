import React from 'react'
import Productslist from '../components/Productslist'

export default function Products() {
  return (
    <>
      <Productslist/>
    </>
  )
}
