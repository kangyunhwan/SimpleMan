import React from 'react'
import Visual from '../components/Visual'
import Categoryfashion from '../components/Categoryfashion'
import Emailbanner from '../components/Emailbanner'
import Salesection from '../components/Salesection'
import Weeklysection from '../components/Weeklysection'


export default function Home() {
  return (
    <>
      <Visual/>
      <Salesection/>
      <Weeklysection/>
      <Categoryfashion/>
      <Emailbanner/>
    </>
  )
}


