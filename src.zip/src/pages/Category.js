import React from 'react'

export default function Category() {
  return (
    <div>Category</div>
  )
}
