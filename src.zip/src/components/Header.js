import React from 'react'
import styles from './css/header.module.css'
import { Link } from 'react-router-dom'
import { FiShoppingBag } from 'react-icons/fi';

export default function Header() {

  const mainMenus=[
    {index:0,path:'/',text:'Home'},
    {index:1,path:'/trending',text:'Trending'},
    {index:2,path:'/products',text:'Products'},
    {index:3,path:'/about',text:'About'}
  ]

  return (
   
    <header>
      <h1 id={styles.logo}><Link to='/'>Simple Man</Link></h1>

      <nav id={styles.mainmenu}>
        <h2 className='hidden'>메인메뉴</h2>
        <ul id={styles.mainmenu_list}>
          {
            mainMenus.map((item)=>(
              <li><Link key={item.index} to={item.path}>{item.text}</Link></li>    
            ))
          }

          {/* <li><Link to='/'>Home</Link></li>
          <li><Link to='/trending'>Trending</Link></li>
          <li><Link to='/category'>Category</Link></li>
          <li><Link to='/about'>About Us</Link></li> */}
        </ul>
      </nav>

      <p className={styles.basket}>
        <button ><FiShoppingBag/></button>
      </p>

      <p className={styles.login}>
        <button>Login</button>
      </p>

      <p className={styles.signup}>
        <button>Sign Up</button>
      </p>
        
    </header>

  )
}
