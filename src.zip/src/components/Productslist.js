
import React, { useCallback, useMemo } from 'react'
import { useState, useEffect } from 'react'
import styles from './css/productslist.module.css'
import { Link } from 'react-router-dom'
import axios from 'axios'
import useProducts from '../hooks/useProducts'

export default function Productslist() {



  const categorys=["전체","상의", "하의", "신발", "가방", "액세서리"]

  const [category, setCategory] = useState(categorys[0])

  //const [categoryItem, setCategoryItem] = useState([])

  //console.log(category)
 
  
 // const [products, setProducts] = useState([])

  //const [allProducts, setAllProducts] = useState([])

  const [products, allProducts]=useProducts()  

  //console.log(allProducts)

  const [categoryItems, setCategoryItems] = useState([])

  //setCategory(allProducts)


  useEffect(()=>{

    //console.log(category)   
    

    if(category==="전체"){
      //console.log(category)  
      //console.log(allProducts)
      setCategoryItems(allProducts)
     
    }else{
      setCategoryItems(allProducts.filter((item)=>(item.category===category)))
    }

  },[category, allProducts])


 

  // useEffect(()=>{

  //   axios.get('/data/products.json').then((res)=>{    

  //     setAllProducts(res.data)    
  //     setProducts(res.data)     

  //   })   

  // },[])



  return (
    <section id={styles.prdlist_wrap}>
      <h2 className='hidden'>상품 리스트</h2>
      <p id={styles.prdlist_title}>
        전체
      </p>
      <ul id={styles.prdlist_catelist}>

        {/* <li className={styles.selected}><Link>전체</Link></li>
        <li><Link>상의</Link></li>
        <li><Link>하의</Link></li>
        <li><Link>신발</Link></li>
        <li><Link>가방</Link></li>
        <li><Link>액세서리</Link></li> */}

        {
          categorys.map((item)=>(

            <li onClick={()=>{               
              setCategory((prev)=>(item)) ;             
            }}><Link>{item}</Link></li>

          ))
        }


      </ul>

      <ul id={styles.prdlist}>
        {/* <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg00.jpg' alt='수피마 컬러 맨투맨(cotton fabric)'/>
            </p>
            <p className={styles.prdlist_name}>
              수피마 컬러 맨투맨(cotton fabric)
            </p>
            <p className={styles.prdlist_price}>
              29,900 원
            </p>
            <p className={styles.prdlist_text}>
              컬러감이 좋아 단품으로 이쁘게 입으실수 있습니다 :)
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 4
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg01.jpg' alt='GREENDALE.반집업 맨투맨(3color)'/>
            </p>
            <p className={styles.prdlist_name}>
              GREENDALE.반집업 맨투맨(3color)
            </p>
            <p className={styles.prdlist_price}>
              39,900 원
            </p>
            <p className={styles.prdlist_text}>
              밑단 스트링 들어가 핏잡아 입기 좋은 반집업 맨투맨입니다
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 12
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg02.jpg' alt='쿨에버 보트넥 스트라이프티(high Q)'/>
            </p>
            <p className={styles.prdlist_name}>
              쿨에버 보트넥 스트라이프티(high Q)
            </p>
            <p className={styles.prdlist_price}>
              29,900 원
            </p>
            <p className={styles.prdlist_text}>
              넥라인 튼튼하고 , 원단 짱짱하네요 , 강추!!
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 6
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg03.jpg' alt='스마일 오버핏 패치 긴팔티(4color)'/>
            </p>
            <p className={styles.prdlist_name}>
              스마일 오버핏 패치 긴팔티(4color)
            </p>
            <p className={styles.prdlist_price}>
              29,900 원
            </p>
            <p className={styles.prdlist_text}>
              인기많은 스마일패치 가을신상 긴팔로 나왔습니다,^^
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 28
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg04.jpg' alt='헤이 스트라이프 반팔티(cotton fabric)'/>
            </p>
            <p className={styles.prdlist_name}>
              헤이 스트라이프 반팔티(cotton fabric)
            </p>
            <p className={styles.prdlist_price}>
              25,000 원
            </p>
            <p className={styles.prdlist_text}>
              적당히 얇고 퀄리티가 좋은 멀티 단가라 반팔입니다:)
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 2
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg05.jpg' alt='할리우드 퀄리티 반팔티(4color)'/>
            </p>
            <p className={styles.prdlist_name}>
              할리우드 퀄리티 반팔티(4color)
            </p>
            <p className={styles.prdlist_price}>
              19,900 원
            </p>
            <p className={styles.prdlist_text}>
              질좋은 원단으로 제작된 레터링 오버 반팔입니다:)
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 4
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg06.jpg' alt='데일리 오버핏 반팔셔츠(cotton fabric)'/>
            </p>
            <p className={styles.prdlist_name}>
              데일리 오버핏 반팔셔츠(cotton fabric)
            </p>
            <p className={styles.prdlist_price}>
              23,000 원
            </p>
            <p className={styles.prdlist_text}>
              여름내내 입기좋은 퀄리티높은 코튼 반팔셔츠입니다,^^
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 6
            </p>
          </Link>
        </li>
        <li>
          <Link >
            <p className={styles.prdlist_prdimg}>
              <img src='./images/prdlist_prdimg07.jpg' alt='앤디 오버핏 체크셔츠(2color)'/>
            </p>
            <p className={styles.prdlist_name}>
              앤디 오버핏 체크셔츠(2color)
            </p>
            <p className={styles.prdlist_price}>
              39,900 원
            </p>
            <p className={styles.prdlist_text}>
              고급스러움이 느껴지는 체크로 제작된 셔츠입니다:)
            </p>
            <p className={styles.prdlist_review}>
              REVIEW : 14
            </p>
          </Link>
        </li> */}

        
      {
          categoryItems.map((item)=>(
            <li key={item.id}>
              <Link to={`/products/${item.id}`}>
                <p className={styles.prdlist_prdimg}>
                  <img src={item.image} alt=''/>
                </p>
                <p className={styles.prdlist_name}>
                  {item.name}
                </p>
                <p className={styles.prdlist_price}>
                  {item.price}
                </p>
              </Link>
            </li>
          ))
        }

      </ul>

    </section>
  )
}
