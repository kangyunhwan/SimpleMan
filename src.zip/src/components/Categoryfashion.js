import React from 'react'
import styles from './css/categoryfashion.module.css'
import { Link } from 'react-router-dom'

export default function Categoryfashion() {
  return (
    <section id={styles.cate_wrap}>
      <h2 className="hidden">카테고리 선택</h2>
      <p id={styles.cate_title}>
        Category Fashion
      </p>
      <p id={styles.cate_subtitle}>
        원하는 카테고리별로 상품을 찾아보세요
      </p>
      <ul id={styles.cate_list}>
      <li>
          <Link>
            <img src='./images/category_all.jpg' alt='전체카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_shirt.jpg' alt='상의카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_pants.jpg' alt='하의카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_bag.jpg' alt='가방카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_shoes.jpg' alt='신발카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_belt.jpg' alt='벨트카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_cap.jpg' alt='모자카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_clock.jpg' alt='시계카테고리'/>
          </Link>
        </li>
        <li>
          <Link>
            <img src='./images/category_outer.jpg' alt='외투카테고리'/>
          </Link>
        </li>

      </ul>

      <p className={styles.cate_morebtn} >
        <button>More Categories</button>
      </p>

    </section>
  )
}
