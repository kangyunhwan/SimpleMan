import React from 'react'
import styles from './css/visual.module.css'

export default function Visual() {
  return (
    <div id={styles.visual}>Visual</div>
  )
}
