import React, { useState, useEffect } from 'react'
import styles from './css/weeklysection.module.css'
import { Link } from 'react-router-dom'
import axios from 'axios'
import useProducts from '../hooks/useProducts'

export default function Weeklysection() {


  const [products, allProducts]=useProducts()

 


  

  const [bestItems, setBestItems]=useState([])


  //const [products, setProducts] = useState([])


  // useEffect(()=>{

  //   axios.get('/data/products.json').then((res)=>{
  //     //setProducts(res.data)
  //     //console.log(products)

  //     const bestItem=res.data.filter((item)=>(item.isBest===true))

  //     //const bestItem=products.filter((item)=>(item.isBest===true))
  //     setProducts(bestItem)
  //   })

   

  // },[])


  useEffect(()=>{

   

    const bestItem=allProducts.filter((item)=>(item.isBest===true))

    setBestItems(bestItem)

  }, [allProducts])






  return (
    <section id={styles.weekprd_wrap}>
      <h2 className='hidden'>이번주 베스트 상품</h2>
      <p id={styles.weekprd_title}>
        Weekly Best Trending
      </p>
      <p id={styles.weekprd_subtitle}>
        이번주 베스트 상품을 만나보세요!
      </p>

      <ul id={styles.weekprd_list}> 
        {/* <li>
          <Link>
            <p className={styles.weekprd_prdimg}>
              <img src='./images/weekprd_prdimg00.jpg' alt='아이스 투턱 세미와이드 슬랙스'/>
            </p>
            <p className={styles.weekprd_name}>
              아이스 투턱 세미와이드 슬랙스
            </p>
            <p className={styles.weekprd_price}>
              35,700
            </p>
          </Link>
        </li>
        <li>
          <Link>
            <p className={styles.weekprd_prdimg}>
              <img src='./images/weekprd_prdimg01.jpg' alt='스톤 아이스 오버 셔츠'/>
            </p>
            <p className={styles.weekprd_name}>
              스톤 아이스 오버 셔츠
            </p>
            <p className={styles.weekprd_price}>
              41,000
            </p>
          </Link>
        </li>
        <li>
          <Link>
            <p className={styles.weekprd_prdimg}>
              <img src='./images/weekprd_prdimg02.jpg' alt='트랜디 워싱청 반팔남방'/>
            </p>
            <p className={styles.weekprd_name}>
              트랜디 워싱 청반팔 남방
            </p>
            <p className={styles.weekprd_price}>
              49,900
            </p>
          </Link>
        </li> */}


        {
          bestItems.map((item)=>(
            <li key={item.id}>
              <Link>
                <p className={styles.weekprd_prdimg}>
                  <img src={item.image} alt=''/>
                </p>
                <p className={styles.weekprd_name}>
                  {item.name}
                </p>
                <p className={styles.weekprd_price}>
                  {item.price}
                </p>
              </Link>
            </li>
          ))
        }







      </ul>

      <p className={styles.weekprd_morebtn} >
        <Link to='/products'>See More Trending</Link>
      </p>
    </section>
  )
}
