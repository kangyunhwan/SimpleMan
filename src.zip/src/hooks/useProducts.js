import React from 'react'
import { useState, useEffect, useMemo } from 'react'
import axios from 'axios'

export default function useProducts() {


  const [products, setProducts] = useState([])

  const [allProducts, setAllProducts] = useState([])

  useEffect(()=>{

    axios.get('/data/products.json').then((res)=>{    

      setAllProducts(res.data)    
      setProducts(res.data)      
     

    })   

    
    

  },[])

  return [products, allProducts]



 
 
}
